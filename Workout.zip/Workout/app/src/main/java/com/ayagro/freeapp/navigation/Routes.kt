package com.ayagro.freeapp.navigation

import kotlinx.serialization.Serializable

sealed class Routes {
    @Serializable
    object MainScreen

    @Serializable
    object ExerciseScreen

}