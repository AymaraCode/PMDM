package com.ayagro.freeapp.viewmodel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ayagro.freeapp.Models.Exercise
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class ExerciseViewModel : ViewModel() {


    private val _username = MutableLiveData<String>()
    val username: LiveData<String> = _username

    private val _reps = MutableLiveData<Int>()
    val reps: LiveData<Int> = _reps

    private val _rep = MutableLiveData<Int>()
    val rep: LiveData<Int> = _rep

    private val _currentExercise = MutableLiveData<Int>()
    val currentExercise: LiveData<Int> = _currentExercise

    private val _doingExercise = MutableLiveData<Boolean>()
    val doingExercise: LiveData<Boolean> = _doingExercise

    private val _exercises = MutableLiveData<List<Exercise>>()
    val exercises : LiveData<List<Exercise>> = _exercises



    fun updateUsername(u: String) { _username.value = u }

    fun updateReps(r: Int) { _reps.value = r }

    fun updateRep(r: Int) { _rep.value = r }

    fun updateCurrentExercise(e: Int) { _currentExercise.value = e }

    fun updateDoingExercise(x: Boolean) { _doingExercise.value = x }

    /*fun beginExercise(){
        _doingExercise.value = true
        _rep.value = reps.value
        _currentExercise.value = exercises.value!!.random().gif
        while (doingExercise.value == true){
            viewModelScope.launch(Dispatchers.IO) {
                if(rep.value == 0) {
                    _rep.postValue(reps.value)
                    _currentExercise.postValue(exercises.value!!.random().gif)
                }
                delay(500)
                _rep.postValue(rep.value?:0.minus(1))
            }



        }

    }*/
    fun beginExercise() {

        viewModelScope.launch(Dispatchers.IO) {
            _doingExercise.postValue(true)
            _rep.postValue(reps.value?:3)
            _currentExercise.postValue(exercises.value!!.random().gif)

            while ( _doingExercise.value == true) {
                if (_rep.value == 0) {
                    _rep.postValue(reps.value)
                    _currentExercise.postValue(exercises.value?.random()?.gif)
                }
                delay(500) // Pausa de 500ms
                _rep.postValue(rep.value?:0.minus(1))
                System.out.println(rep.value)
            }


        }
    }

    init {
        createExList()
    }


    fun createExList() {

        viewModelScope.launch(Dispatchers.IO) {
            _exercises.postValue(Exercise.getData())
        }

    }



}