package com.ayagro.freeapp.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.ayagro.freeapp.R
import com.ayagro.freeapp.navigation.Routes
import com.ayagro.freeapp.viewmodel.ExerciseViewModel


@Composable
fun MainScreen(navController: NavHostController,exerciseViewModel: ExerciseViewModel) {
    var nombre by remember { mutableStateOf("") }
    val reps: Int by exerciseViewModel.reps.observeAsState(3)

    Column {
        Text(
            text = "Suda, sonríe y haz ejercicio otra vez",
            fontSize = 30.sp
        )
        TextField(
            value = nombre,
            onValueChange = { n: String -> nombre = n},
            placeholder = { Text("Introduce tu nombre",
            modifier = Modifier.padding(5.dp)) }
        )
        Row {
            Text(text = "Repeticiones :",
                fontSize = 30.sp)
            Text(text = reps.toString())
            Column {
                Button(onClick = { exerciseViewModel.updateReps(reps + 1)}) {
                    Text(text = "^")
                }
                Button(onClick = { if(reps > 3) exerciseViewModel.updateReps(reps - 1) }) {
                    Text(text = "v")
                }
            }
        }
        Button(onClick = {
            exerciseViewModel.updateUsername(nombre)
            navController.navigate(Routes.ExerciseScreen)
        }, 
            enabled = nombre.isNotEmpty()) {
            Text(text = "Comenzar")
        }
        Row{
            Image(painter = painterResource(id = R.drawable.aymarafoto),
                contentDescription = "Foto de Aymara",
                modifier = Modifier
                    .width(150.dp)
                    .weight(1f))
            Column (
                modifier = Modifier.weight(1f)
            ){
                Spacer(modifier = Modifier.weight(1f))
                Text(text = "Aymara Aguayo Rojas",
                    modifier = Modifier.weight(1f))
                Spacer(modifier = Modifier.weight(1f))
            }

        }
    }
}
