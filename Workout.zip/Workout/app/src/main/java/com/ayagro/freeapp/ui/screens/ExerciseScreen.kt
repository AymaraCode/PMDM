package com.ayagro.freeapp.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import com.ayagro.freeapp.Models.Exercise
import com.ayagro.freeapp.viewmodel.ExerciseViewModel
import java.lang.Exception

@Composable
fun ExerciseScreen(navController: NavHostController, exerciseViewModel: ExerciseViewModel){

    val rep: Int by exerciseViewModel.rep.observeAsState(0)
    val nombre: String by exerciseViewModel.username.observeAsState("")
    val ex: Int by exerciseViewModel.currentExercise.observeAsState(0)

    exerciseViewModel.beginExercise()

    Column {
        Text(text = "Tu puedes " + nombre)
        Row {
            Text(text = "Repeticiones: ")
            Text(text = rep.toString() )
        }
        GifImage(gifImage = ex) //Aqui tambien hay que unir
        Button(onClick = {
            exerciseViewModel.updateDoingExercise(false)
            navController.popBackStack()
        }) {
            Text(text = "Volver")
            Text(text = "<-")
        }
    }
}

@Composable
fun GifImage(gifImage: Int) {}
/*
@Composable
fun GifImage(gifImage: Int) {
    val imageLoader = ImageLoader.Builder(LocalContext.current)
        .components {
            if (Build.VERSION.SDK_INT >= 28) {
                add(AnimatedImageDecoder.Factory())
            } else {
                add(GifDecoder.Factory())
            }
        }
        .build()

    Image(
        painter = rememberAsyncImagePainter(
            ImageRequest.Builder(LocalContext.current)
                .data(data = gifImage)
                .apply(
                    block = fun ImageRequest.Builder.() {
                        size(Size.ORIGINAL)
                    }
                )
                .build(),
            imageLoader = imageLoader
        ),
        contentDescription = null,
    )
}
*/