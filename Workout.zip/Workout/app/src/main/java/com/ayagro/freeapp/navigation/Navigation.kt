package com.ayagro.freeapp.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.ayagro.freeapp.ui.screens.ExerciseScreen
import com.ayagro.freeapp.ui.screens.MainScreen
import com.ayagro.freeapp.viewmodel.ExerciseViewModel

@Composable
fun Navigation(){
    val navController = rememberNavController()
    val exerciseViewModel = remember { ExerciseViewModel() }

    NavHost(navController = navController, startDestination = Routes.MainScreen){
        composable<Routes.MainScreen>{
            MainScreen(navController, exerciseViewModel)
        }
        composable<Routes.ExerciseScreen> {
            ExerciseScreen(navController, exerciseViewModel)
        }
    }
}