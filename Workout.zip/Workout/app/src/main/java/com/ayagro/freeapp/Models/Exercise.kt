package com.ayagro.freeapp.Models

import com.ayagro.freeapp.R


class Exercise (
    val name : String,
    val gif : Int
){

    companion object{
        fun getData() : List<Exercise> {
            return listOf(
                Exercise("Saltos levantando rodillas", R.drawable.jumps),
                Exercise("Bicicleta en plancha", R.drawable.biciplancha),
                Exercise("Fondos en una silla", R.drawable.fondos)
            )
        }
    }
}